# راهنمای سریع - PushTutor

## نصب در 5 دقیقه

### گام ۱: Clone

```bash
git clone <repo-url>
cd pushtutor
```

### گام ۲: Setup

```bash
chmod +x setup.sh
./setup.sh
```

### گام ۳: Configure

```bash
nano .env
```

**حداقل کانفیگ برای Bot API:**
```env
BOT_TOKEN=123456:ABC-DEF...
ADMIN_IDS=123456789
GEMINI_API_KEY=AIza...
ENABLE_USERBOT=false
ENABLE_BOT=true
```

**حداقل کانفیگ برای Userbot:**
```env
TELEGRAM_API_ID=12345678
TELEGRAM_API_HASH=abcdef...
TELEGRAM_PHONE=+989123456789
ADMIN_IDS=123456789
GEMINI_API_KEY=AIza...
ENABLE_USERBOT=true
ENABLE_BOT=false
```

### گام ۴: اجرا

```bash
./run.sh
```

## مثال‌های استفاده

### مثال ۱: کاربر عادی می‌خواد پایتون یاد بگیره

**کاربر:**
```
می‌خوام پایتون رو از صفر یاد بگیرم
```

**ربات:**
```
چند سوال سریع:
1. سطح: مبتدی کامل؟
2. هدف: شغل / پروژه شخصی / کنجکاوی؟
3. چقدر وقت داری در هفته؟ (ساعت)
```

**کاربر:**
```
مبتدی کامل، می‌خوام شغل پیدا کنم، ۱۰ ساعت در هفته
```

**ربات:**
```
برنامه یادگیری ۳ ماهه پایتون برای ورود به بازار کار:

📚 مرحله ۱: پایه‌ها (۴ هفته)
🔹 کانال‌های پیشنهادی:
   • @PythonFarsi - آموزش پایتون به فارسی
   • @LearnPython - تمرین‌های روزانه
   
📝 چی یاد بگیری:
   - متغیرها و data types
   - شرط و حلقه
   - توابع
   - OOP پایه

🎯 تمرین: ماشین حساب ساده

📚 مرحله ۲: پروژه‌های کاربردی (۶ هفته)
...
```

### مثال ۲: کاربر کانال پیشنهاد می‌کنه

**کاربر:** (forward از کانال)
```
این کانال خوبه برای یادگیری React
```

**ربات:**
```
✅ کانال "React Persian" به لیست پیشنهادات اضافه شد.
پس از بررسی ادمین‌ها، به لیست کانال‌های آموزشی اضافه می‌شه.
```

### مثال ۳: ادمین کانال اضافه می‌کنه

**ادمین:** (reply به forward)
```
/addchannel آموزش React - سطح متوسط - فارسی
```

**ربات:**
```
✅ کانال "React Persian" به لیست کانال‌های خوب اضافه شد.
```

### مثال ۴: ادمین وضعیت چک می‌کنه

**ادمین:**
```
/status
```

**ربات:**
```
🤖 وضعیت PushTutor

✅ Bot API: Active
✅ Userbot: Active
🧠 LLM Provider: gemini
📊 Available Providers: gemini, openai
💾 Database: Connected
🗂 Curated Channels: 23
📝 Pending Suggestions: 5
👥 Active Conversations: 12
```

### مثال ۵: ادمین پیشنهادات رو بررسی می‌کنه

**ادمین:**
```
/suggestions
```

**ربات:**
```
📋 پیشنهادات در انتظار

🆔 ID: 1
📢 JavaScript Mastery
   @js_master
👤 User: 123456789
💬 عالی برای مبتدی‌ها

🆔 ID: 2
📢 Python Tips
   @python_tips_fa
👤 User: 987654321

/approve <id> - تایید
/reject <id> - رد
```

**ادمین:**
```
/approve 1
```

**ربات:**
```
✅ پیشنهاد 1 تایید شد و به لیست اضافه شد.
```

### مثال ۶: تغییر LLM Provider

**ادمین:**
```
/setprovider openai
```

**ربات:**
```
✅ Provider changed to openai
```

## سناریوهای پیشرفته

### استفاده همزمان Userbot + Bot

**در گروه (Userbot):**
```
@username می‌خوام Django یاد بگیرم
```

**در خصوصی (Bot):**
```
/start
می‌خوام Django یاد بگیرم
```

هر دو به یک LLM متصل هستند ولی context مجزا دارند.

### Conversation Context

```
کاربر: می‌خوام Machine Learning یاد بگیرم
ربات: [توضیحات و سوالات]

کاربر: مبتدی هستم
ربات: [برنامه مبتدی]

کاربر: اون کانالی که گفتی لینکش رو بده
ربات: [لینک کانال - context aware]
```

پاک کردن context:
```
/clear
```

## Tips & Tricks

### برای کاربران

1. **واضح باش:**
   ❌ "یه چیزی یاد بده"
   ✅ "می‌خوام برنامه‌نویسی وب رو یاد بگیرم"

2. **سطح رو مشخص کن:**
   "می‌خوام React یاد بگیرم - JavaScript رو بلدم"

3. **زمان رو بگو:**
   "یه برنامه ۲ هفته‌ای بچین"

### برای ادمین‌ها

1. **کانال با metadata اضافه کن:**
   ```
   /addchannel سطح: پیشرفته، زبان: انگلیسی، موضوع: AI
   ```

2. **پیشنهادات رو سریع بررسی کن:**
   ```
   /suggestions
   /approve 1 2 3
   ```

3. **Monitor کن:**
   ```
   tail -f logs/pushtutor.log
   ```

## Common Issues

### ربات جواب نمی‌ده

```bash
# چک logs
tail -f logs/pushtutor.log

# چک API keys
cat .env | grep API_KEY

# ری‌استارت
./run.sh
```

### Userbot connect نمی‌شه

```bash
# حذف session و دوباره connect
rm userbot_session.session
python main.py
```

### Out of Memory

```env
# در .env کم کن
ENABLE_VECTOR_SEARCH=false
```

## دستورات پرکاربرد

```bash
# نصب
./setup.sh

# اجرا
./run.sh

# لاگ‌ها
tail -f logs/pushtutor.log

# پاک کردن cache
rm -rf __pycache__

# Rebuild database
rm pushtutor.db
python -c "from database import db_manager; db_manager.create_tables()"

# Check syntax
python -m py_compile *.py
```

## Next Steps

بعد از setup:

1. ✅ کانفیگ `.env`
2. ✅ اجرای ربات
3. 📱 تست با `/start`
4. 👥 اضافه کردن ادمین‌ها
5. 📚 اضافه کردن کانال‌های اولیه
6. 🚀 شروع استفاده

برای جزئیات بیشتر:
- [README.md](README.md)
- [DEPLOYMENT.md](DEPLOYMENT.md)
